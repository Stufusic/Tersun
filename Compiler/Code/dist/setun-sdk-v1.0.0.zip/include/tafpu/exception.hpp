#pragma once

#include <stdexcept>
#include <string>

namespace setun {

// Base exception for all Setun/TAFPU runtime errors
class SetunException : public std::runtime_error {
public:
    explicit SetunException(const std::string& msg) : std::runtime_error(msg) {}
};

// TAFPU specific algebraic exception
class TafpuException : public SetunException {
public:
    explicit TafpuException(const std::string& msg) : SetunException(msg) {}
};

// Isotropic Division Exception (A2^2 - 3*B2^2 == 0)
// Dividing by an isotropic element in Q(sqrt(3))
class IsotropicDivisionException : public TafpuException {
public:
    explicit IsotropicDivisionException(const std::string& msg = "Algebraic Exception: Division by isotropic element or zero in Q(sqrt(3)) (A^2 - 3*B^2 == 0)")
        : TafpuException(msg) {}
};

// VM execution exception
class VMException : public SetunException {
public:
    explicit VMException(const std::string& msg) : SetunException(msg) {}
};

// Compiler error exception
class CompilerException : public SetunException {
public:
    explicit CompilerException(const std::string& msg) : SetunException(msg) {}
};

} // namespace setun
